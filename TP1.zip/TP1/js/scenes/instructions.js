
export class Instructions extends Phaser.Scene {

    constructor() {
        super("Instructions");
    }

    create() {

    }
}