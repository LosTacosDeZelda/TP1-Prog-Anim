/**
 * Classe affichant les instructions pour mobile ou
 * pour ordi
 */
export class Instructions extends Phaser.Scene {

    constructor() {
        super("Instructions");
    }

    create() {

    }
}