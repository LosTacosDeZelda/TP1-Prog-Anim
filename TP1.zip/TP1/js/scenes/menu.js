
/**
 * Classe représentant le menu principal du jeu
 */

export class Menu extends Phaser.Scene{

    constructor(){
        super("Menu");

        this.boutonJouer;
    }

    create(){
        //this.boutonJouer = this.add.rectangle(window.innerWidth/2,window.innerHeight/2,100,50,0xffffff);

        this.input.keyboard.on("keydown-F",this.gererPleinEcran,this);

        console.log("FullScreenAvailable : " + this.sys.game.device.fullscreen.available);

        // si on est sur ordinateur
        if(window.orientation == undefined){

            // afficher l'image et la mettre à la bonne taille
            this.menuBG = this.add.image(0, 0,"menuBG");
            this.menuBG.setOrigin(0,0);
            this.menuBG.setScale(0.53,0.53);

            // afficher le personnage du menu
            this.menuPerso = this.add.image(0,0,"menuPerso");
            this.menuPerso.setOrigin(0,0);
            this.menuPerso.setScale(0.4,0.4);

            // boutons du menu
            this.boutonJouer = this.add.bitmapText(this.game.scale.width,this.game.scale.height/2,"SF-Fedora","Jouer");
            this.boutonJouer.setOrigin(1.2,1);

            // Nom du jeu
            this.menuTexte = this.add.bitmapText(this.game.scale.width,0,"SF-Fedora","John Jones",100);
            this.menuTexte.text = "FullScreenAvailable : " + this.sys.game.device.fullscreen.available;
            this.menuTexte.setOrigin(1.1,0);
    
        }
        // si on est sur mobile à l'horizontale
        else if(window.orientation == 90 || window.orientation == -90){

            // afficher l'image et la mettre à la bonne taille
            this.menuBG = this.add.image(screen.width/2, 0,"menuBG");
            this.menuBG.setOrigin(0.45,0);
            this.menuBG.setScale(0.53,0.53);

            // afficher le personnage du menu
            this.menuPerso = this.add.image(0,0,"menuPerso");
            this.menuPerso.setOrigin(0.15,0);
            this.menuPerso.setScale(0.4,0.4);

            // boutons du menu
            this.boutonJouer = this.add.bitmapText(screen.width,screen.height/2,"SF-Fedora","Jouer");
            this.boutonJouer.setOrigin(1.15,1);

            // texte du menu
            this.menuTexte = this.add.bitmapText(window.innerWidth/1.05,0,"SF-Fedora","John Jones",100);
            this.menuTexte.text = "FullScreenAvailable : " + this.sys.game.device.fullscreen.available;
            this.menuTexte.setOrigin(1,0);
        }

        /*
        // si on est sur mobile mais que l'écran est vertical
        else if (window.orientation == 0){
            // message pour tourner l'écran
            this.menuTexte = this.add.bitmapText(this.game.scale.width/2, this.game.scale.height/2,"SF-Fedora","Tourner votre écran à l'horizontal",70);
            this.menuTexte.setOrigin(0.5);
        }
        */
       
        //this.input.on("gameobjectover",this.hover)

        this.boutonJouer.setInteractive();
        this.boutonJouer.on("pointerdown",this.chargerScene, this);

        console.log("window orientation : " + window.orientation);
        console.log("canvas size : " + this.game.scale.width);

        
    }

    update(){

    }



    //Fonctions personnelles
    chargerScene(){
        this.scene.start("niveau1");
    }

    gererPleinEcran(){
        console.log("enter");
        if (this.scale.isFullscreen) {

            this.scale.stopFullscreen();
        }
        else{

            this.scale.startFullscreen();
        }
        
    }
}