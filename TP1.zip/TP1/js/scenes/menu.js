


export class Menu extends Phaser.Scene{

    constructor(){
        super("Menu");

        this.boutonJouer;
    }

    create(){
        this.boutonJouer = this.add.rectangle(window.innerWidth/2,window.innerHeight/2,100,50,0xffffff);
        //this.add.text(500,500,"Jouer");

        this.boutonJouer.setInteractive();
        this.boutonJouer.on("pointerdown",this.loadScene, this);
    }

    update(){
        
    }

    //Fonctions personnelles
    loadScene(){
        this.scene.start("level1");
    }
}